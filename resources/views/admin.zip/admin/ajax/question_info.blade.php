<div class="col-md-1">
    Total MCQ : <b>{{ $total_mcq }}</b>
</div>
<div class="col-md-1">
    Total SBA : <b>{{ $total_sba }}</b>
</div>
<div class="col-md-1">
    Total Mark : <b>{{ $total_mark }}</b>
</div>
<div class="col-md-2">
    Duration : <b>{{ $duration }}</b> Min
</div>
<div class="col-md-2">
    Negative Mark : <b>{{ $negative_mark }}</b>
</div>