<label class="col-md-3 control-label">Add Class/Chapter</label>
<div class="col-md-3">
    {!! Form::select('topic_id[]',$topics, '',['class'=>'form-control topic2','multiple','required'=>'required']) !!}<i></i>
</div>
