<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class DoctorEducations extends Model
{

    protected $table = 'doctors_education';

}
