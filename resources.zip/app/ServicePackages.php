<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class ServicePackages extends Model
{
    protected $table = 'service_packages';

    public $timestamps = false;
}
