<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class BcpsFaculty extends Model
{
    protected $table = 'bcps_faculties';

    public $timestamps = false;

    
}
