<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Upazilas extends Model
{
    protected $table = 'upazilas';
}
