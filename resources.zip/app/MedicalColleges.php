<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class MedicalColleges extends Model
{
    protected $table = 'medical_colleges';
}
