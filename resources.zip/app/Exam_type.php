<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Exam_type extends Model
{
    protected $table = 'exam_type';
}
