@if ($email_status==1)
<input class="hidden" type="text" name='email_hidden' required="required">Email Already Exists.
@endif