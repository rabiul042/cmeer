@if ($bmdc_status==1)
<input class="hidden" type="text" name='bmdc_no_hidden' required="required">BMDC Already Exists.
@endif